const express = require('express');
const cors = require("cors");
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;
const FILE_PATH = path.join(__dirname, 'data.json');

// Middleware to parse incoming JSON in POST requests
app.use(express.json());
app.use(cors());

// GET endpoint: send the JSON file contents
app.get('/data', (req, res) => {
    // console.log("get recieved")
  fs.readFile(FILE_PATH, 'utf8', (err, data) => {
    if (err) {
    //   <Quote>"res.status(500).json({ error: 'Could not read file' })"</Quote>
    console.log("some damn error: "+err)
      return res.status(500).json({ error: 'Could not read file' });
    }
    // Send parsed JSON back
    res.setHeader('Content-Type', 'application/json');
    res.send(data);
  });
});

app.post('/data', (req, res) => {
  console.log("headers:", req.headers);
  console.log("body:", req.body);

  const newData = JSON.stringify(req.body, null, 2);
  console.log("newData:", newData);

  fs.writeFile(FILE_PATH, newData, "utf8", (err) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: "Could not save file" });
    }

    res.json({ ok: true });
  });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
